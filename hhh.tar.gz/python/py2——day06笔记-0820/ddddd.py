from getpass import getpass
userdb = {}

def login():
     username = input('username: ')
     password = getpass('password: ')
     if userdb.get(username) != password:
         print('账号或者密码错误')
     else:
         print('登陆成功')

def zhuce():
    username = input('username: ')
    if username not in userdb:
        password = input('password: ')
        userdb[username] = password
        print('您已经成功注册')
    else:
        print('%s已存在' % username)

def show_menu():
      mmm = {'0':  zhuce, '1': login }
      prompt = '''(0) 新用户注册
(1) 登陆
(2) 退出
请选择(0/1/2): '''
      while True:
          xxx = input(prompt).strip()[0]
          if xxx not in '012':
              print('无效的输入，请选择“0 1 2”')
              continue
          if xxx == 2:
              break

          mmm[xxx]()

if __name__ == '__main__':
    show_menu()

