import sys

print(sys.argv)  # argv是sys模块中的列表，用于存储位置参数

