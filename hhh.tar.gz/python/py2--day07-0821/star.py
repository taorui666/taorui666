hi = 'Hello World!'

def pstar(n=30):
    print('*' * n)

def foo():
    print(len('abc'))

