import star

star.pstar()
print(star.hi)
star.pstar(50)

