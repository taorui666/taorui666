hi = 'Hello World!'

def pstar(n=30):
    print('*' * n)

if __name__ == '__main__':
    pstar()
