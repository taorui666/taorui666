# https://www.jianshu.com/c/00c61372c46a

username = input('username: ')
print('Welcome', username)
print('Welcome ' + username)

# PEP8

a = 10 + 5  # 变量赋值，自右向左进行
a = a + 10  # 可以简化为以下形式
a += 10
# b += 10  # 错误，因为等价于b = b + 10，b没有提前赋值

print(5 / 2)  # 2.5
print(5 // 2)  # 2
print(5 % 2)  # 只要余数，模运算，1
print(2 ** 3)  # 2的3次方，8

20 > 10 > 5  # True，它相当于下面的写法
10 > 10 and 10 > 5




