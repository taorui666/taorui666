if 3 > 0:
    print('ok')
    print('yes')

if 'a' in 'abc' and 10 > 5:
    print('对')

if True:
    print('true')

if 10 > 20:
    print('yes')
else:
    print('no')

# 可以把数据类型直接当成判断条件
# 任何值为0的数字都是False，否则为True
# 任何非空对象都是True，否则为False
if -0.0:
    print('yes')
if -0.1:
    print('yes')
if ' ':
    print('yes')
if '':
    print('yes')

